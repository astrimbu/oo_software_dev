package hw1;

import static org.junit.Assert.*;

import org.junit.Test;

public class InventorySetTest {

	@Test
	public void testInventorySet() {
		fail("Not yet implemented");
	}

	@Test
	public void testSize() {
		fail("Not yet implemented");
	}

	@Test
	public void testGet() {
		fail("Not yet implemented");
	}

	@Test
	public void testToCollection() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddNumOwned() {
		fail("Not yet implemented");
	}

	@Test
	public void testCheckOut() {
		fail("Not yet implemented");
	}

	@Test
	public void testCheckIn() {
		fail("Not yet implemented");
	}

	@Test
	public void testClear() {
		fail("Not yet implemented");
	}

	@Test
	public void testToString() {
		fail("Not yet implemented");
	}

}
